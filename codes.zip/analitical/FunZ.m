%IHN
function z=FunZ(lb1,r1,r2,w,l1,f1,R1,c1,f2,R2,c2 )
syms z
z=vpasolve(z-(f1*l1/(l1+R1*w*(0.5*((r2+lb1*(1-z)+r1)+sqrt((r2+lb1*(1-z)+r1)^2-4*((lb1*(1-z)+r1)*r2-r1*r2))))/c1)+f2*l1/(l1+R2*w*(0.5*((r2+lb1*(1-z)+r1)+sqrt((r2+lb1*(1-z)+r1)^2-4*((lb1*(1-z)+r1)*r2-r1*r2))))/c2)),z);

%  R1z=lb1*(1-z)+r1;
% R2z=r2;
% Rz=R1z+R2z;
% Wz=0.5*((r2+lb1*(1-z)+r1)+sqrt((r2+lb1*(1-z)+r1)^2-4*((lb1*(1-z)+r1)*r2-r1*r2)));
% tet=Wz; 
% ss=f1*l1/(l1+R1*w*tet/c1)+f2*l1/(l1+R2*w*tet/c2)+f3*l1/(l1+R3*w*tet/c3);
% rz=solve('z-f1*l1/(l1+R1*w*tet/c1)+f2*l1/(l1+R2*w*tet/c2)+f3*l1/(l1+R3*w*tet/c3)','z')


