%IHN
clc
clear all
close all 
%%%
N=10000; % # of nodes 
S=12;   % Number of messages per day
pr=0.8;  % 90\% uplink
Gu=N*S/(24*3600)*pr; 
Gd=N*S/(24*3600)*(1-pr);

Pt1=0.2; Pt2=0.2;  Pc=0.01; al=1; Pl=0.1; PI=0.01;


% R1=10000;R2=12000;R3=14000;
% dR1=12000;dR2=14000;dR3=16000;
% c1=3;c2=2;c3=1;
% Dsyn1=1; Dsyn2=0.66;Dsyn3=0.33;

Dsyn1=0.33;Dsyn2=0.66;
R1=5000;R2=5000;
dR1=15000;dR2=15000;
c1=1;c2=2;

f1=1/2;f2=1/2;
l1=1000;m1=10000;
l2=l1^2;m2=m1^2;

u= 0.002; ta=0.005;
M=16;
b=0.2;
lab=5;
Tth=2;
% d=.005;
% t=.06;
% dRg=0.002:0.002:.2;
% tRg=0.002:0.002:.2;
% 
% dRg=[0.015:0.1:  1 ];5
% tRg=[0.2 :0.038: 0.55 ];
dRg=[0.002, 0.003,0.004,0.005,0.006,0.007, 0.008,0.01:0.005:   .2 ];
tRg=[0.002, 0.003,0.004,0.005,0.006,0.007, 0.008,0.01:0.005:   .2 ];
% dRg=0.01;
% tRg=0.2;
 
itK=length(dRg)*length(tRg);

sLT1=nan(length(dRg),length(tRg));
sLT2=nan(length(dRg),length(tRg));
sDu1=nan(length(dRg),length(tRg));
sDu2=nan(length(dRg),length(tRg));
sDd1=nan(length(dRg),length(tRg));
sDd2=nan(length(dRg),length(tRg));


ii=0;
id=0;
for d=dRg 
    id=id+1;
    it=0; 
    for t=tRg
        it=it+1;
        ii=ii+1; 
        [ii/itK]
         
        Qr=max(1,(Gu+Gd)*t);
        p_rach=((M-1)/M)^(Qr-1);

        xl=lab*d+(Gu+Gd)*max(d,t);
        
        F1=[f1,f2]';
        C1=[c1,c2]';
        
%         j=0;
%         for K=2:2*floor(xl)  %floor(lab*d+(Gu+Gd)*max(d,t));
%             for k=1:K-1
%                 j=j+1;
%                 Fc1=1-Fcdf(F1,C1,K-k, Tth,u);
%                 if(K-k-1>0)
%                     Fc2=Fcdf(F1,C1,K-k-1, Tth,u);
%                 else
%                     Fc2=1;
%                 end
%                 PF1=poF(xl,K);
%                 %         HH(j,:)=[k,K,k/K,PF1*Fc1*Fc2];
%                 X=X+k/K*PF1*Fc1*Fc2;
%             end
%         end
        X=0;
        p_rar=1-X;
        ps=p_rach*p_rar;
        Dra=0.5*t;
        
        bDt=(f1*c1+f2*c2)*u;
        mQ=(Gu+Gd)*max(d,t)+lab*d;
        Drar1=0.5*d+0.5*mQ*bDt+c1*u;
        Drar2=0.5*d+0.5*mQ*bDt+c2*u;
        

 
        w=1-(c1*ta+c2*ta)/t; 
        s1=f1*c1*l1/(R1*w)+f2*c2*l1/(R2*w) ;
        G=(f1*Gu*t+f2*Gu*t);
        rou= G*s1/t;
        
        if(rou>0.99 || rou<0 || isnan(rou)|| isinf(rou))
            continue
          
        end   
        [Dtx1,Dtx2]=dFun(c1,c2,f1,f2,t,R1,R2,l1,l2,w,Gu);
           
        y=1-(b+xl*bDt/d);
        h1=f1*c1*m1/(dR1*y)+f2*c2*m1/(dR2*y) ;
        G=(f1*Gd*t+f2*Gd*t);
        rod= G*h1/t;
        
        if(rod>0.99 || rod<0 || isnan(rod)|| isinf(rod))
            continue
        end   
        [Drx1,Drx2]=dFun(c1,c2,f1,f2,t,dR1,dR2,m1,m2,y,Gd); 
          
              
        Du1=Dsyn1+1/ps*(Dra+Drar1)+Dtx1; 
        Du2=Dsyn2+1/ps*(Dra+Drar2)+Dtx2;
        Dd1=Dsyn1+1/ps*(Dra+Drar1)+Drx1; 
        Dd2=Dsyn2+1/ps*(Dra+Drar2)+Drx2;
  
         
        Esyn1=Pl*Dsyn1;
        Esyn2=Pl*Dsyn2;
        Erar1=Pl*Drar1;
        Erar2=Pl*Drar2;
        
        Era1=(Dra-c1*ta)*PI+c1*ta*(Pc+al*Pt1);
        Era2=(Dra-c2*ta)*PI+c2*ta*(Pc+al*Pt2);
        
        Etx1=(Dtx1-c1*l1/(R1*1))*PI+(Pc+al*Pt1)*c1*l1/(R1*1);
        Etx2=(Dtx2-c2*l1/(R2*1))*PI+(Pc+al*Pt2)*c2*l1/(R2*1);

        
        Erx1=(Drx1-c1*m1/(dR1*1))*PI+(Pl)*c1*m1/(dR1*1);
        Erx2=(Drx2-c2*m1/(dR2*1))*PI+(Pl)*c2*m1/(dR2*1);
 
        
        Eu1=Esyn1+1/ps*(Era1+Erar1)+Etx1;
        Eu2=Esyn2+1/ps*(Era2+Erar2)+Etx2;

        Ed1=Esyn1+1/ps*(Era1+Erar1)+Erx1;
        Ed2=Esyn2+1/ps*(Era2+Erar2)+Erx2;

        %
         
        
        E0=1000;    
          
        LT1=E0/(S*pr*Eu1+S*(1-pr)*Ed1);
        LT2=E0/(S*pr*Eu2+S*(1-pr)*Ed2);

        
        sLT1(id,it)=LT1;
        sLT2(id,it)=LT2; 

        sDu1(id,it)=Du1;  
        sDu2(id,it)=Du2; 

        sDd1(id,it)=Dd1;
        sDd2(id,it)=Dd2;

        sRO(id,it,1:2)=[rou,rod];
        
%         sLT(ii,:)=[LT1,LT2,LT3];
%         sDL(ii,:)=[Du1,Du2,Du3,Dd1,Dd2,Dd3];
%         sRO(ii,:)=[rou,rod];
    end
end
save datatestm.mat
% I1=and(sRO>0,sRO<1);
% I2=and(I1(:,1),I1(:,2));
% nsRO=sRO(I2);
% nsDL=sDL(I2,:);
% nsLT=sLT(I2,:);

%% plot
clc
clear all
close all 
load datatestm.mat
[tt,dt] = meshgrid(tRg,dRg);
figure
surface(dt,tt,sLT1)
view(3)
grid
xlabel('d(sec)')
ylabel('t(sec)')
zlabel('Lifetime(days)')
hold on
surface(dt,tt,sLT2)
hold off
 

figure
surface(dt,tt,sDu1)
view(3)
grid
xlabel('d(sec)')
ylabel('t(sec)')
zlabel('Uplink delay(sec)')
hold on
surface(dt,tt,sDu2)
hold off
 
figure
surface(dt,tt,sDd1)
view(3)
grid
xlabel('d(sec)')
ylabel('t(sec)')
zlabel('Downlink delay(sec)')
hold on
surface(dt,tt,sDd2)
hold off
  
ALt=sLT1(1,:);
ADt=sDd1(1,:);
AUt=sDu1(1,:);
ALd=sLT1(:,length(dRg));
ADd=sDd1(:,length(dRg));
AUd=sDu1(:,length(dRg));
figure
yyaxis right
plot(dRg,ALd/max(ALd))
hold on
plot(dRg,ADd/max(ADd))
plot(dRg,AUd/max(AUd))
yyaxis left
plot(tRg,ALt/max(ALt))
plot(tRg,ADt/max(ADt))
plot(tRg,AUt/max(AUt))
hold off

m=max(max(sLT2));
[a,b]=find(sLT2==m);
dRg(a)
tRg(b)

m=min(min(sDu2));
[a,b]=find(sDu2==m);
dRg(a) 
tRg(b)

m=min(min(sDd2));
[a,b]=find(sDd2==m);
dRg(a)
tRg(b)