function [FF,CC]=Fmer(F1,F2,C1,C2)

f1=length(F1);
f2=length(F2);
% f3=f1*f2;
% FF=zeros(f3,1);
% CC=zeros(f3,1);
FF=kron(F1,F2);
CC=log(kron(exp(C1),exp(C2)));
% for i=1:f2
% %     FF(f1*(i-1)+1:f1*(i-1)+f1,1)=F2(i)*F1;
%     CC(f1*(i-1)+1:f1*(i-1)+f1,1)=C2(i)+C1;
% end



