function y=Fcdf(F1,C1,g,Tth,u)
FF=F1;
CC=C1;

for i=2:g
    [FF,CC]=Fmer(FF,F1,CC,C1);
    
end 

[sCC,b]=sort(CC);
sFF=FF(b); 
ID=sCC*u<Tth; 
y=sum(sFF(ID));






