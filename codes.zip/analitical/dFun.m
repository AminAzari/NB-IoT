%IHN
function [Dtx1,Dtx2 ]=dFun(c1,c2, f1,f2, t,R1,R2 ,l1,l2,w,Gu)
 
s1=f1*c1*l1/(R1*w)+f2*c2*l1/(R2*w) ; 
% l2=l1^2;
s2=f1*c1^2*l2/(R1^2*w^2)+f2*c2^2*l2/(R2^2*w^2) ;

% s2=2*c1*l1/(R1*w)*c2*l1/(R2*w); 
G=f1*Gu*t+f2*Gu*t; 
ro= G*s1/t;  
     

Dtx1=0.5*ro*s2/(s1*(1-ro))+G*s1/(2*(1-ro))+c1*l1/(R1*w);
Dtx2=0.5*ro*s2/(s1*(1-ro))+G*s1/(2*(1-ro))+c2*l1/(R2*w);
