load data3.mat

[tt,dt] = meshgrid(tRg,dRg);
figure
surface(dt,tt,sLT3)
view(3)
grid 
xlabel('t(sec)')
ylabel('d(sec)') 
zlabel('Lifetime(days)')
   
figure
surface(dt,tt,sDu3)
view(3)
grid
xlabel('t(sec)')
ylabel('d(sec)')
zlabel('Lifetime(days)')

figure
surface(dt,tt,sDd3)
view(3)
grid
xlabel('t(sec)')
ylabel('d(sec)')
zlabel('Lifetime(days)')

 
m=max(max(sLT3));
[a,b]=find(sLT3==m);
dRg(a)
tRg(b)

m=min(min(sDu3));
[a,b]=find(sDu3==m);
dRg(a)
tRg(b)

m=min(min(sDd3));
[a,b]=find(sDd3==m);
dRg(a)
tRg(b)




ALt=sLT3(1,:);
ADt=sDd3(1,:);
AUt=sDu3(1,:);
ALd=sLT3(:,14);
ADd=sDd3(:,14);
AUd=sDu3(:,14);
figure
yyaxis right
plot(dRg,ALd/max(ALd))
hold on
plot(dRg,ADd/max(ADd))
plot(dRg,AUd/max(AUd))
yyaxis left
plot(tRg,ALt/max(ALt))
plot(tRg,ADt/max(ADt))
plot(tRg,AUt/max(AUt))
hold off

