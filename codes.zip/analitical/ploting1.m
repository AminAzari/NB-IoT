load data3.mat

[tt,dt] = meshgrid(tRg,dRg);
figure
surface(dt,tt,sLT1)
view(3)
grid 
xlabel('t(sec)') 
ylabel('d(sec)') 
zlabel('Lifetime(days)')
[a_megh,a_mak]=max(max(sLT1));
[b_megh,b_mak]=max(sLT1(:,a_mak));
[b_mak,a_mak] 

figure
surface(dt,tt,sDu1)
view(3)
grid
xlabel('t(sec)')
ylabel('d(sec)')
zlabel('Lifetime(days)')

figure
surface(dt,tt,sDd1)
view(3)
grid
xlabel('t(sec)')
ylabel('d(sec)')
zlabel('Lifetime(days)')

 
m=max(max(sLT1));
[a,b]=find(sLT1==m);
dRg(a)
tRg(b)

m=min(min(sDu1));
[a,b]=find(sDu1==m);
dRg(a)
tRg(b)

m=min(min(sDd1));
[a,b]=find(sDd1==m);
dRg(a)
tRg(b)




ALt=sLT1(1,:);
ADt=sDd1(1,:);
AUt=sDu1(1,:);
ALd=sLT1(:,14);
ADd=sDd1(:,14);
AUd=sDu1(:,14);
figure
yyaxis right
plot(dRg,ALd/max(ALd))
hold on
plot(dRg,ADd/max(ADd))
plot(dRg,AUd/max(AUd))
yyaxis left
plot(tRg,ALt/max(ALt))
plot(tRg,ADt/max(ADt))
plot(tRg,AUt/max(AUt))
hold off

