clc
clear vars
close all

load data3.mat

[tt,dt] = meshgrid(tRg,dRg);
subplot(3,1,1)
surface(dt,tt,sLT1)
view(3)
grid 
xlabel('t(sec)')
ylabel('d(sec)') 
zlabel('Lifetime(days)')
[a_megh,a_mak]=max(max(sLT1));
[b_megh,b_mak]=max(sLT1(:,a_mak));
[b_mak,a_mak] 

[tt,dt] = meshgrid(tRg,dRg);
subplot(3,1,2)
surface(dt,tt,sLT2)
view(3)
grid 
xlabel('t(sec)')
ylabel('d(sec)') 
zlabel('Lifetime(days)')
[a_megh,a_mak]=max(max(sLT2));
[b_megh,b_mak]=max(sLT2(:,a_mak));
[b_mak,a_mak] 

[tt,dt] = meshgrid(tRg,dRg);
subplot(3,1,3)
surface(dt,tt,sLT3)
view(3)
grid 
xlabel('t(sec)')
ylabel('d(sec)') 
zlabel('Lifetime(days)')
[a_megh,a_mak]=max(max(sLT3));
[b_megh,b_mak]=max(sLT3(:,a_mak));
[b_mak,a_mak] 
