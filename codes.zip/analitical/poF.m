%IHN
function y=poF(xl,k) 
y=xl^k*exp(-xl)/factorial(k);